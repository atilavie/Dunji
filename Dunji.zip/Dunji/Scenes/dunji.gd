extends Sprite2D

const BOARD_HEIGHT = 16
const BOARD_WIDTH = 20
const CELL_WIDTH = 18

const TEXTURE_HOLDER = preload("res://Scenes/texture_holder.tscn")

const RED_BISHOP = preload("res://dunji_assets/red_bishop.png")
const RED_KING = preload("res://dunji_assets/red_king.png")
const RED_KNIGHT = preload("res://dunji_assets/red_knight.png")
const RED_PAWN = preload("res://dunji_assets/red_pawn.png")
const RED_QUEEN = preload("res://dunji_assets/red_queen.png")
const RED_ROOK = preload("res://dunji_assets/red_rook.png")
const RED_GENERAL = preload("res://dunji_assets/red_general.png")
const RED_SPY = preload("res://dunji_assets/red_spy.png")
const RED_MONK = preload("res://dunji_assets/red_monk.png")
const RED_SPEARMAN = preload("res://dunji_assets/red_spearman.png")
const RED_WALL = preload("res://dunji_assets/red_wall.png")
const RED_TOWER = preload("res://dunji_assets/red_tower.png")
const RED_CASTLE = preload("res://dunji_assets/red_castle.png")
const RED_CATAPULT = preload("res://dunji_assets/red_catapult.png")
const RED_RAM = preload("res://dunji_assets/red_ram.png")
const RED_CANNON = preload("res://dunji_assets/red_cannon.png")
const BLUE_BISHOP = preload("res://dunji_assets/blue_bishop.png")
const BLUE_KING = preload("res://dunji_assets/blue_king.png")
const BLUE_KNIGHT = preload("res://dunji_assets/blue_knight.png")
const BLUE_PAWN = preload("res://dunji_assets/blue_pawn.png")
const BLUE_QUEEN = preload("res://dunji_assets/blue_queen.png")
const BLUE_ROOK = preload("res://dunji_assets/blue_rook.png")
const BLUE_GENERAL = preload("res://dunji_assets/blue_general.png")
const BLUE_SPY = preload("res://dunji_assets/blue_spy.png")
const BLUE_MONK = preload("res://dunji_assets/blue_monk.png")
const BLUE_SPEARMAN = preload("res://dunji_assets/blue_spearman.png")
const BLUE_WALL = preload("res://dunji_assets/blue_wall.png")
const BLUE_TOWER = preload("res://dunji_assets/blue_tower.png")
const BLUE_CASTLE = preload("res://dunji_assets/blue_castle.png")
const BLUE_CATAPULT = preload("res://dunji_assets/blue_catapult.png")
const BLUE_RAM = preload("res://dunji_assets/blue_ram.png")
const BLUE_CANNON = preload("res://dunji_assets/blue_cannon.png")
var TURN_MARKER = preload("res://dunji_assets/timer.png")
const PIECE_SHADOW = preload("res://dunji_assets/piece_shadow.png")
const BLUE_MOVE_EMPTY = preload("res://dunji_assets/blue_move_empty.png")
const BLUE_MOVE_SELECTED = preload("res://dunji_assets/blue_move_selected.png")
const BLUE_MOVE_OCCUPIED = preload("res://dunji_assets/blue_move_occupied.png")
const RED_MOVE_EMPTY = preload("res://dunji_assets/red_move_empty.png")
const RED_MOVE_SELECTED = preload("res://dunji_assets/red_move_selected.png")
const RED_MOVE_OCCUPIED = preload("res://dunji_assets/red_move_occupied.png")

@onready var pieces = $Pieces
@onready var dots = $Dots
@onready var turn = $Turn
var dungeon_template : Array
var board : Array
var blue : bool = true
var state : bool = false
var moves = []
var selected_piece : Vector2
var stage : int = 0
var en_passant = null
var selected_team_blue = true
var false_capture = false
var castle_use = false
var config = ConfigFile.new()
var loaded_save = null
var move_from_team = 1
var administrator = false
var together = false
func _ready():
	dungeon_template.push_front([  1,  1,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,-14,-15, -7])#	16: = WALL
	dungeon_template.push_front([  1,  1,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,-16,-16, -9])#	15: = TOWER
	dungeon_template.push_front([  1,  1,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -2, -2,-12])#	14: = CASTLE
	dungeon_template.push_front([  1,  1,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -2, -2,-12])#	13: = SPEARMAN
	dungeon_template.push_front([  4, 13, 13,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,-11,-11, -3])#	12: = RAM
	dungeon_template.push_front([  4, 13, 13,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,-11,-11, -3])#	11: = MONK
	dungeon_template.push_front([ 10,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -6])#	10: = GENERAL
	dungeon_template.push_front([  5,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -8])#	9: = CATAPULT
	dungeon_template.push_front([  8,  0, 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -5])#	8: = SPY
	dungeon_template.push_front([  6,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,-10])#	7: = CANNON
	dungeon_template.push_front([  3, 11, 11,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,-13,-13, -4])#	6: = KING
	dungeon_template.push_front([  3, 11, 11,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,-13,-13, -4])#	5: = QUEEN
	dungeon_template.push_front([ 12,  2,  2,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1, -1, -1])#	4: = ROOK
	dungeon_template.push_front([ 12,  2,  2,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1, -1, -1])#	3: = BISHOP
	dungeon_template.push_front([  9, 16, 16,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1, -1, -1])#	2: = KNIGHT
	dungeon_template.push_front([  7, 15, 14,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1, -1, -1])#	1: = PAWN
	
	load_save(0)
	board_sort()
	enforce_turns()
func _process(_delta: float) -> void:
	display_board()

func _input(event):
	if event.is_action_pressed("Click"):
		var var1 = snapped(get_global_mouse_position().x, 0) / CELL_WIDTH
		var var2 = abs(snapped(get_global_mouse_position().y, 0)) / CELL_WIDTH
		if is_mouse_out(): return
		if !state && ((blue && board[var2][var1] > 0) || (!blue && board[var2][var1] < 0) || board[var2][var1] == 17 || (administrator && !(board[var2][var1] ==0))):
			selected_piece = Vector2(var2, var1)
			show_options()
			state = true
			return
		elif state:
			var1 = snapped(get_global_mouse_position().x, 0) / CELL_WIDTH
			var2 = abs(snapped(get_global_mouse_position().y, 0)) / CELL_WIDTH
			set_move(var2, var1)
			return
		
	if event.is_action_released("Click") && state: 
		if is_mouse_out(): return
		var var1 = snapped(get_global_mouse_position().x, 0) / CELL_WIDTH
		var var2 = abs(snapped(get_global_mouse_position().y, 0)) / CELL_WIDTH
		if selected_piece.x == var2 && selected_piece.y == var1: 
			return
		set_move(var2, var1)
	
	if event.is_action_pressed("Reload"):
		get_tree().reload_current_scene()
		load_save(loaded_save)
		delete_dots()
		state = false
	if event.is_action_pressed("ui_cancel"):
		save(0)
		get_tree().change_scene_to_file("res://Scenes/menu.tscn")
	if event.is_action_pressed("Load 1"):
		load_save(1)
		delete_dots()
		state = false
		save(0)
	if event.is_action_pressed("Load 2"):
		load_save(2)
		delete_dots()
		state = false
		save(0)
	if event.is_action_pressed("Load 3"):
		load_save(3)
		delete_dots()
		state = false
		save(0)
	if event.is_action_pressed("Load 4"):
		load_save(4)
		delete_dots()
		state = false
		save(0)
	if event.is_action_pressed("Load 5"):
		load_save(5)
		delete_dots()
		state = false
		save(0)
	if event.is_action_pressed("Load 6"):
		load_save(6)
		delete_dots()
		state = false
		save(0)
	if event.is_action_pressed("Load 7"):
		load_save(7)
		delete_dots()
		state = false
		save(0)
	if event.is_action_pressed("Load 8"):
		load_save(8)
		delete_dots()
		state = false
		save(0)
	if event.is_action_pressed("Load 9"):
		load_save(9)
		delete_dots()
		state = false
		save(0)
	if event.is_action_pressed("Save"):
		save(loaded_save)
	if event.is_action_pressed("Admin"):
		_on_check_button_button_up()
	board_sort()

func save(save_value):
	config.set_value("saves", str(save_value), board)
	config.set_value("settings", "rotation", GlobalOrientation.blue_perspective)
	config.save("res://config.cfg")

func load_save(save_value):
	var err = config.load("res://config.cfg")
	if err == OK:
		$"../Camera2D/Control/RotationButton".button_pressed = !config.get_value("settings", "rotation")
		GlobalOrientation.blue_perspective = config.get_value("settings", "rotation")
		if !(config.get_value("saves", str(save_value)) == null):
			board = config.get_value("saves", str(save_value))
			loaded_save = save_value
		else:
			config.set_value("saves", str(save_value), dungeon_template)
			board = config.get_value("saves", str(save_value))
			loaded_save = save_value
	
	enforce_turns()

func is_mouse_out():
	if get_global_mouse_position().x < 0: return true
	if get_global_mouse_position().y > 0: return true
	if get_global_mouse_position().x > 359: return true
	if get_global_mouse_position().y < -287: return true
	return false

func display_board():
	$"../Camera2D".rotation_degrees = 0 if GlobalOrientation.blue_perspective else 180
	for child in pieces.get_children():
		child.queue_free()
	var o = 1 if round($"../Camera2D".rotation_degrees) == 180 else -1
	for i in BOARD_HEIGHT:
		for j in BOARD_WIDTH:
			var holder = TEXTURE_HOLDER.instantiate()
			var holder_shadow = TEXTURE_HOLDER.instantiate()
			pieces.add_child(holder_shadow)
			pieces.add_child(holder)
			holder_shadow.global_position = Vector2((j * CELL_WIDTH + (CELL_WIDTH / 2)) - o, (-i * CELL_WIDTH - (CELL_WIDTH / 2)) - o)
			holder.global_position = Vector2((j * CELL_WIDTH + (CELL_WIDTH / 2)), (-i * CELL_WIDTH - (CELL_WIDTH / 2)))
			if board[i][j] != 0:
				holder_shadow.texture = PIECE_SHADOW
			match board[i][j]:
				-16: holder.texture = RED_WALL
				-15: holder.texture = RED_TOWER
				-14: holder.texture = RED_CASTLE
				-13: holder.texture = RED_SPEARMAN
				-12: holder.texture = RED_RAM
				-11: holder.texture = RED_MONK
				-10: holder.texture = RED_GENERAL
				-9: holder.texture = RED_CATAPULT
				-8: holder.texture = RED_SPY
				-7: holder.texture = RED_CANNON
				-6: holder.texture = RED_KING
				-5: holder.texture = RED_QUEEN
				-4: holder.texture = RED_ROOK
				-3: holder.texture = RED_BISHOP
				-2: holder.texture = RED_KNIGHT
				-1: holder.texture = RED_PAWN
				0: holder.texture = null
				17: holder.texture = TURN_MARKER
				16: holder.texture = BLUE_WALL
				15: holder.texture = BLUE_TOWER
				14: holder.texture = BLUE_CASTLE
				13: holder.texture = BLUE_SPEARMAN
				12: holder.texture = BLUE_RAM
				11: holder.texture = BLUE_MONK
				10: holder.texture = BLUE_GENERAL
				9: holder.texture = BLUE_CATAPULT
				8: holder.texture = BLUE_SPY
				7: holder.texture = BLUE_CANNON
				6: holder.texture = BLUE_KING
				5: holder.texture = BLUE_QUEEN
				4: holder.texture = BLUE_ROOK
				3: holder.texture = BLUE_BISHOP
				2: holder.texture = BLUE_KNIGHT
				1: holder.texture = BLUE_PAWN

func match_sort(g : int):
	match abs(g):
		1 : return 16
		2 : return 15
		3 : return 8
		4 : return 7
		5 : return 6
		6 : return 1
		7 : return 10
		8 : return 5
		9 : return 11
		10: return 9
		11: return 13
		12: return 12
		13: return 14
		14: return 2
		15: return 3
		16: return 4
		_: return 18

func show_options():
	moves = get_moves(selected_piece)
	if moves == []:
		state = false
		return
	show_dots()
	
func show_dots():
	for i in moves:
		if get_board(i) != 0:
			var holder = TEXTURE_HOLDER.instantiate()
			dots.add_child(holder)
			if selected_team_blue:
				holder.texture = BLUE_MOVE_OCCUPIED
			else:
				holder.texture = RED_MOVE_OCCUPIED
			holder.global_position = Vector2(i.y * CELL_WIDTH + (CELL_WIDTH / 2), -i.x * CELL_WIDTH - (CELL_WIDTH / 2))
		else:
			var holder = TEXTURE_HOLDER.instantiate()
			dots.add_child(holder)
			if selected_team_blue:
				holder.texture = BLUE_MOVE_EMPTY
			else:
				holder.texture = RED_MOVE_EMPTY
			holder.global_position = Vector2(i.y * CELL_WIDTH + (CELL_WIDTH / 2), -i.x * CELL_WIDTH - (CELL_WIDTH / 2))
	if get_board(selected_piece) != 0:
		var turn_selected_holder = TEXTURE_HOLDER.instantiate()
		dots.add_child(turn_selected_holder)
		if selected_team_blue:
			turn_selected_holder.texture = BLUE_MOVE_SELECTED
		else:
			turn_selected_holder.texture = RED_MOVE_SELECTED
		turn_selected_holder.global_position = Vector2(selected_piece.y * CELL_WIDTH + (CELL_WIDTH / 2), -selected_piece.x * CELL_WIDTH - (CELL_WIDTH / 2))
func delete_dots():
	for child in dots.get_children():
		child.queue_free()

func enforce_turns():
	if board[7][2] == 17:
		blue = true
		stage = 0
	if board[8][2] == 17:
		blue = false
		stage = 0
	if board[7][17] == 17:
		blue = true
		stage = 1
	if board[8][17] == 17:
		blue = false
		stage = 1
func set_move(var2, var1):
	if var2 > 15: return
	if var1 > 20: return
	var just_now = false
	var move_to_space = Vector2(var2, var1)
	var move_to_id = board[var2][var1]
	var move_from_space = selected_piece
	var move_from_id = get_board(move_from_space)
	together = false
	castle_use = false
	move_from_team = 1 if (move_from_id > 0) else -1
	
	if move_to_id > 0:
		selected_team_blue = true
	elif move_to_id < 0:
		selected_team_blue = false
	for i in moves:
		if i.x == var2 && i.y == var1:
			if !administrator:
				special_behavior(move_from_id, move_from_space, move_to_space, move_to_id, i, just_now, var1, var2)
			if false_capture:
				if move_from_id == get_board(move_from_space):
					set_board(move_from_space, 0)
				if !castle_use:
					dungeon_capture(move_from_id)
				else:
					castle_store(move_from_id)
			else:
				set_board(move_to_space, move_from_id)
				
				if move_from_id == get_board(move_from_space):
					set_board(move_from_space, 0)
				
			if !has_candidates() && !administrator:
				blue = !blue
				var side = [2,17]
				for w in side:
					board[7][w] = board[7][w] + board[8][w]
					board[8][w] = board[7][w] - board[8][w]
					board[7][w] = board[7][w] - board[8][w]
			
			if !(is_empty(move_to_space) || false_capture || together):
				dungeon_capture(move_to_id)
				
			if stage == 0:
				placement_end()
			break
	delete_dots()
	enforce_turns()
	get_result()
	state = false
	
	if !((selected_piece.x != var2 || selected_piece.y != var1) && ((move_from_id * move_from_team > 0))):
		return
	if !administrator && !(board[var2][var1] == 17):
		selected_piece = Vector2(var2, var1)
		if !(dungeon(move_from_space) && stage == 1):
			show_options()
			state = true
func special_behavior(move_from_id, move_from_space, move_to_space, move_to_id, i, just_now, var1, var2):
	match abs(move_from_id):
		1:
			if (i.x == move_from_space.x + (2 * move_from_team)) && (i.y == move_from_space.y):
				en_passant = i
				just_now = true
			elif en_passant != null && en_passant.y == i.y && move_from_space.y != i.y && en_passant.x == move_from_space.x:
				board[en_passant.x][en_passant.y] = 0
		10:
			if move_to_id == (2 * move_from_team):
				together = true
			move_with(move_from_space, move_to_space, (2 * move_from_team))
		11:
			if !((move_to_id * move_from_team) > 0):
				dungeon_fetch(abs(move_to_id))
		3:
			if !((move_to_id * move_from_team) > 0):
				dungeon_fetch(abs(move_to_id))
			if (move_to_id * move_from_team) == 11:
				together = true
			move_with(move_from_space, move_to_space, 11 * move_from_team)
	if !just_now: en_passant = null
	false_capture = false
	var destinations = [Vector2(1,0), Vector2(3,0), Vector2(2,0)]
	if board[var2][var1] == (7 * move_from_team):
		for r in destinations:
			if battlefield(i+(r * move_from_team)):
				dungeon_capture(board[var2 + (r.x * move_from_team)][var1])
				board[var2 + (r.x * move_from_team)][var1] = 0
		set_board(move_to_space, 7 * move_from_team)
		false_capture = true
	elif (board[var2][var1] == (14 * move_from_team)):
		set_board(move_to_space, 14 * move_from_team)
		false_capture = true
		castle_use = true
func get_moves(selected : Vector2):
	var _moves = []
	move_from_team = 1 if (get_board(selected) > 0) else -1
	if get_board(selected) > 0:
		selected_team_blue = true
	elif get_board(selected) < 0:
		selected_team_blue = false
	if !administrator:
		if blue && move_from_team == -1:
			return _moves
		if !blue && move_from_team == 1:
			return _moves
	if administrator && !(get_board(selected) == 17):
		_moves = []
		admin_placement(selected, _moves)
		return _moves
	if stage == 0 && !(get_board(selected) == 17):
		_moves = []
		if dungeon(selected) && is_dungeon_space():
			opening_placement(selected, _moves)
		elif dungeon(selected) && abs(get_board(selected)) == 14:
			opening_placement(selected, _moves)
	if stage == 1:
		if castle(selected):
			placement(selected, _moves)
		if has_candidates():
			_moves = []
			if dungeon(selected):
				promotion(selected, _moves)
	if (!king_in_castle() || ((selected.x < 6) && blue) || ((selected.x > 9) && !blue)) && ((battlefield(selected) && stage == 1)):
		match abs(get_board(selected)):
			1: _moves = get_pawn_moves(selected)
			2: _moves = get_knight_moves(selected)
			3: _moves = get_bishop_moves(selected)
			4: _moves = get_rook_moves(selected)
			5: _moves = get_queen_moves(selected)
			6: _moves = get_king_moves(selected)
			7: _moves = get_cannon_moves(selected)
			8: _moves = get_spy_moves(selected)
			9: _moves = get_catapult_moves(selected)
			10: _moves = get_general_moves(selected)
			11: _moves = get_monk_moves(selected)
			12: _moves = get_ram_moves(selected)
			13: _moves = get_spearman_moves(selected)
	if (administrator && is_board(selected, 17)):
		_moves = turn_marker_moves(selected)
	moves_cull(_moves)
	return _moves
func moves_cull(_moves):
	_moves.sort()
	for i in range(0, _moves.size()):
		if i < _moves.size()-1 && (_moves[i] == _moves[i+1]):
			_moves.remove_at(i)
func board_sort():
	for e in range(0,5):
		for n in range(4,15):
			var castle_pos = Vector2(0, n)
			var castle1 = board[castle_pos.x][castle_pos.y]
			var castle2 = board[castle_pos.x][castle_pos.y + 1]
			if match_sort(castle1) > match_sort(castle2):
				board[castle_pos.x][castle_pos.y + 1] = castle1
				board[castle_pos.x][castle_pos.y] = castle2
		for n in range(-15,-4):
			var castle_pos = Vector2(15, -n)
			var castle1 = board[castle_pos.x][castle_pos.y]
			var castle2 = board[castle_pos.x][castle_pos.y -1]
			if match_sort(castle1) > match_sort(castle2):
				board[castle_pos.x][castle_pos.y -1] = castle1
				board[castle_pos.x][castle_pos.y] = castle2
	for a in range(0,15):
		for c in range(0,20):
			for b in range(c-2,20):
				if dungeon_template[a][b] == board[a+1][c] && board[a][b] == 0 && dungeon(Vector2(a+1,c)) && (board[a+1][c] > 0):
					board[a][b] = dungeon_template[a][b]
					board[a+1][c] = 0
					break
				if board[a][b] == dungeon_template[a+1][c] && board[a+1][c] == 0 && dungeon(Vector2(a,b)) && (board[a][b] < 0):
					board[a][b] = 0
					board[a+1][c] = dungeon_template[a][b]
					break
	for a in range(0,16):
		for b in range(1,20):
			if dungeon_template[a][b] == board[a][b-1] && board[a][b] == 0 && !battlefield(Vector2(a,b-1)) && (board[a][b-1] > 0):
				board[a][b] = dungeon_template[a][b]
				board[a][b-1] = 0
			if dungeon_template[a][b-1] == board[a][b] && board[a][b-1] == 0 && !battlefield(Vector2(a,b-1)) && (board[a][b] < 0):
				board[a][b] = 0
				board[a][b-1] = dungeon_template[a][b]

func opening_placement(selected: Vector2, _moves):
	var pos = Vector2(0, 0)
	if dungeon(selected):
		for c in range(2,14):
			for b in range(4,16):
				pos = Vector2(c, b)
				if battlefield(pos) && is_empty(pos) && ((pos.x < 6 && blue) || (pos.x > 9 && !blue)): 
					_moves.append(pos)

func placement_end():
	var piece_locations = []
	var pos = Vector2(0, 0)
	for c in range(0,16):
		for b in range(0, 20):
			pos = Vector2(c, b)
			if dungeon(pos) && board[c][b] != 0:
				piece_locations.append(pos)
	if piece_locations.size() == 24:
		for g in piece_locations:
			if has_castle_room:
				castle_store(board[g.x][g.y])
				board[g.x][g.y] = 0
		board[7][17] = 17
		board[7][2] = 0

func placement(selected: Vector2, _moves):
	var directions = [Vector2(0, 1), Vector2(0, -1), Vector2(1, 0), Vector2(-1, 0),
	Vector2(1, 1), Vector2(1, -1), Vector2(-1, 1), Vector2(-1, -1)]
	if !castle(selected):
		return
	for c in range(2,14):
		for b in range(4,16):
			var pos = Vector2(c, b)
			if !is_empty(pos):
				continue
			for i in directions:
				var place_helper = [5,14,15,16]
				var place_check = pos + i
				if place_helper.has(move_from_team * get_board(place_check)):
					_moves.append(pos)
func promotion(selected: Vector2, _moves):
	var pos = Vector2(0, 0)
	var c = null
	if dungeon(selected):
		c = 13 if blue else 2
	else: return
	for b in range(4,16):
		pos = Vector2(c, b)
		if battlefield(pos) && is_board(pos, 1) && !is_board(selected, 1): 
			_moves.append(pos)
func has_candidates():
	var pos = Vector2(0, 0)
	var candidates = []
	var can_promote = false
	for c in range(0,16):
		for b in range(0 if blue else 16,4 if blue else 20):
			pos = Vector2(c, b)
			if dungeon(pos) && !is_empty(pos) && !is_board(pos, 1):
				candidates.append(pos)	
	var v = 13 if blue else 2
	for b in range(4,16):
		pos = Vector2(v, b)
		if battlefield(pos) && is_board(pos, 1):
			can_promote = true
	if (candidates.size() > 0) && can_promote:
		return true
	return false
func admin_placement(selected: Vector2, _moves):
	var pos = Vector2(0, 0)
	for c in range(0,16):
		for b in range(0, 20):
			pos = Vector2(c, b)
			if (battlefield(pos) || (!dungeon(selected) && dungeon(pos) && is_empty(pos) && (get_board(selected) == dungeon_template[pos.x][pos.y])) || castle(pos)) && selected != pos: 
				_moves.append(pos)

func battlefield(pos):
	if pos.x > 1 && pos.y < 16 && pos.y > 3 && pos.x < 14: 
		return true
	return false

func dungeon(pos):
	if pos.y < 3 && pos.x < 6 && pos.y > -1 && pos.x > -1:
		return true
	elif pos.y < 3 && pos.x > 9 && pos.y > -1 && pos.x < 16:
		return true
	elif pos.y == 0 && pos.x > 5 && pos.x < 10:
		return true
	elif pos.y < 20 && pos.x < 6 && pos.y > 16 && pos.x > -1:
		return true
	elif pos.y < 20 && pos.x > 9 && pos.y > 16 && pos.x < 16:
		return true
	elif pos.y == 19 && pos.x > 5 && pos.x < 10:
		return true
	return false

func castle(pos):
	if !((pos.x == 0 && selected_team_blue) || (pos.x == 15 && !selected_team_blue)):
		return false
	if pos.y >= 4 && pos.y <= 15:
		return true
	return false
func has_castle_room():
	var f = 0
	if !selected_team_blue:
		f = 15
	for d in range(4,16):
		if is_empty(Vector2(f,d)):
			return true
	return false
func dungeon_fetch(move_to_id_enemy):
	var success = false
	var empty_castle_space = Vector2(0,0)
	for n in range(4 if blue else -15, 16 if blue else -3):
		var castle_pos = Vector2(0 if (move_from_team == 1) else 15, n if (move_from_team == 1) else -n)
		if is_empty(castle_pos):
			empty_castle_space = castle_pos
	if empty_castle_space == Vector2(0,0):
		return
	if move_from_team == 1 && board[0][2] == 14:
		return
	if move_from_team == -1 && board[15][17] == -14:
		return
	for g in range(0, 16):
		for r in range(0, 20):
			var candidate_space = Vector2(g,r)
			if dungeon(candidate_space) && !success:
				if get_board(candidate_space) == (move_to_id_enemy * move_from_team):
					set_board(candidate_space, 0)
					castle_store(move_to_id_enemy * move_from_team)
					success = true
	if success: return
	for g in range(0, 16):
		for r in range(0, 20):
			var candidate_space = Vector2(g,r)
			if dungeon(candidate_space) && !success:
				if get_board(candidate_space) == (1 * move_from_team):
					set_board(candidate_space, 0)
					castle_store(1 * move_from_team)
					success = true
func dungeon_capture(piece):
	var success = false
	for g in range(0, 16):
		for r in range(0, 20):
			if dungeon_template[g][r] == piece && !success && board[g][r] == 0:
				board[g][r] = piece
				success = true
	if piece == 14:
		selected_team_blue = true
	elif piece == -14:
		selected_team_blue = false
	else: return
	for g in range(0, 16):
		for r in range(0, 20):
			if castle(Vector2(g,r)):
				var piece_extract = board[g][r]
				board[g][r] = 0
				dungeon_capture(piece_extract)
func is_dungeon_space():
	for g in range(0, 16):
		for r in range(0 if blue else 9, 9 if blue else 20):
			if dungeon(Vector2(g,r)) && board[g][r] == 0:
				return true
	return false
func castle_store(piece):
	for n in range(4 if (piece>0) else -15, 16 if (piece>0) else -3):
		var castle_pos = Vector2(0 if (piece>0) else 15, n if (piece>0) else -n)
		if is_empty(castle_pos):
			board[castle_pos.x][castle_pos.y] = piece
			break
func move_with(move_from_space, move_to_space, follower):
	var directions = [Vector2(0, 1), Vector2(0, -1), Vector2(1, 0), Vector2(-1, 0), Vector2(1, 1), Vector2(1, -1), Vector2(-1, 1), Vector2(-1, -1)]
	var comrades = []
	var comrades_bring = []
	var comrades_leave = []
	for h in directions:
		var comrade_test = move_from_space + h
		if battlefield(comrade_test):
			if board[comrade_test.x][comrade_test.y] == follower:
				comrades.append(h)
	for t in comrades:
		var comrades_remove = move_from_space + t
		board[comrades_remove.x][comrades_remove.y] = 0
	for g in comrades:
		var comrades_destination = move_to_space + g
		if battlefield(comrades_destination):
			if is_empty(comrades_destination) || (get_board(comrades_destination) == get_board(move_from_space)):
				comrades_bring.append(g)
			else: comrades_leave.append(g)
		else: comrades_leave.append(g)
	for l in comrades_bring:
		set_board(move_to_space + l, follower)
	for o in comrades_leave:
		set_board(move_from_space + o, follower)
func exception_handler(pos, _moves, piece_position):
	if is_board(pos, 7):
		var direction
		if blue: direction = Vector2(1, 0)
		else: direction = Vector2(-1, 0)
		if battlefield(pos + direction):
			_moves.append(pos)
	elif is_board(pos, 9):
		var direction
		direction = [Vector2(1, 1), Vector2(1, -1), Vector2(2, 2), Vector2(2, -2), Vector2(3, 3), Vector2(3, -3)]
		for n in direction:
			n = n * (1 if blue else -1)
			if battlefield(pos + n) && ((pos + n) != piece_position):
				_moves.append(pos + n)
	elif is_board(pos, 14):
		for n in range(4, 16):
			var castle_pos = Vector2(0 if blue else 15, n)
			if is_empty(castle_pos):
				_moves.append(pos)
				break
	elif is_board(pos, 15):
		var direction = [Vector2(0, 1), Vector2(0, -1), Vector2(1, 0), Vector2(-1, 0),
						Vector2(1, 1), Vector2(1, -1), Vector2(-1, 1), Vector2(-1, -1)]
		for r in direction:
			var check = pos + r
			for k in direction:
				if check == piece_position + k && battlefield(piece_position + k) && battlefield(piece_position + 2 * k) && (is_empty(piece_position + 2 * k)) && is_child(piece_position, piece_position + k):
					_moves.append(piece_position + k)
			if (is_enemy(check) || is_empty(check)) && battlefield(check):
				_moves.append(check)
func is_child(pos1, pos2):
	if get_board(pos1) == (3 * move_from_team) && get_board(pos2) == (11 * move_from_team):
		return true
	if get_board(pos1) == (10 * move_from_team) && get_board(pos2) == (2 * move_from_team):
		return true
	return false
func king_in_castle():
	for n in range(4 if blue else -15, 16 if blue else -3):
		var castle_pos = Vector2(0 if blue else 15, n if blue else -n)
		if board[castle_pos.x][castle_pos.y] == (6 if blue else -6):
			return true
	return false
func get_board(get_pos):
	var output = board[get_pos.x][get_pos.y]
	return output
func set_board(get_pos, piece_id):
	board[get_pos.x][get_pos.y] = piece_id
func get_pawn_moves(piece_position : Vector2):
	var _moves = []
	var direction
	var is_safe = false
	var pos
	
	if blue: direction = Vector2(1, 0)
	else: direction = Vector2(-1, 0)
	
	if home_ranks(piece_position): is_safe = true
	if en_passant != null && abs(en_passant.y - piece_position.y) == 1 && piece_position.x == en_passant.x:
		pos = en_passant + direction
		if is_empty(pos):
			_moves.append(pos)
	pos = piece_position + direction
	if battlefield(pos):
		if is_empty(pos):
			_moves.append(pos)
		else: exception_handler(pos, _moves, piece_position)
	pos = piece_position + Vector2(direction.x, 1)
	if battlefield(pos):
		if is_enemy(pos):
			_moves.append(pos)
	pos = piece_position + Vector2(direction.x, -1)
	if battlefield(pos):
		if is_enemy(pos):
			_moves.append(pos)
	pos = piece_position + direction * 2
	if is_safe && is_empty(piece_position + direction) && battlefield(pos):
		if  is_empty(pos):
			_moves.append(pos)
		else: exception_handler(pos, _moves, piece_position)
	return _moves
func get_knight_moves(piece_position : Vector2):
	var movement_pattern = "knight"
	var building_capture = false
	var companion = 0
	var movement_range = 1
	var infiltrator = false
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func get_bishop_moves(piece_position : Vector2):
	var movement_pattern = "diagonal"
	var building_capture = false
	var companion = 11
	var movement_range = -1
	var infiltrator = false
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func get_rook_moves(piece_position : Vector2):
	var movement_pattern = "straight"
	var building_capture = false
	var companion = 0
	var movement_range = -1
	var infiltrator = false
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func get_queen_moves(piece_position : Vector2):
	var movement_pattern = "straight, diagonal"
	var building_capture = false
	var companion = 0
	var movement_range = 1
	var infiltrator = false
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func get_king_moves(piece_position : Vector2):
	var movement_pattern = "straight, diagonal"
	var building_capture = false
	var companion = 0
	var movement_range = 1
	var infiltrator = false
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func get_cannon_moves(piece_position : Vector2):
	var movement_pattern = "straight, diagonal"
	var building_capture = true
	var companion = 0
	var movement_range = 1
	var infiltrator = false
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func get_spy_moves(piece_position : Vector2):
	var movement_pattern = "straight, diagonal"
	var building_capture = false
	var companion = 0
	var movement_range = -1
	var infiltrator = true
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func get_catapult_moves(piece_position : Vector2):
	var movement_pattern = "straight, diagonal"
	var building_capture = true
	var companion = 0
	var movement_range = 1
	var infiltrator = false
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func get_general_moves(piece_position : Vector2):
	var movement_pattern = "straight, diagonal, knight"
	var building_capture = true
	var companion = 2
	var movement_range = 1
	var infiltrator = false
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func get_monk_moves(piece_position : Vector2):
	var movement_pattern = "diagonal"
	var building_capture = false
	var companion = 0
	var movement_range = 2
	var infiltrator = false
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func get_ram_moves(piece_position : Vector2):
	var movement_pattern = "straight, diagonal"
	var building_capture = true
	var companion = 0
	var movement_range = 1
	var infiltrator = false
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func get_spearman_moves(piece_position : Vector2):
	var movement_pattern = "straight"
	var building_capture = false
	var companion = 0
	var movement_range = 2
	var infiltrator = false
	return movement(movement_pattern, building_capture, piece_position, companion, movement_range, infiltrator)
func turn_marker_moves(piece_position : Vector2):
	var _moves = []
	if !administrator: return _moves
	var directions = [Vector2(7, 2), Vector2(8, 2), Vector2(7, 17), Vector2(8, 17)]
	for i in directions:
		var pos = i
		if pos != piece_position:
			_moves.append(pos)
	return _moves
func is_empty(pos : Vector2):
	if (pos.x <= 15 && pos.x >= 0) && (pos.y <= 20 && pos.y >= 0):
		if get_board(pos) == 0: return true
	return false
func is_enemy(pos : Vector2):
	if blue && get_board(pos) in range(-13,0) || !blue && get_board(pos) in range(1,14): return true
	return false
func is_enemy_incl(pos : Vector2):
	if blue && get_board(pos) < 0 || !blue && get_board(pos) > 0: return true
	return false
func get_result():
	if is_conquest_victory():
		if blue:
			print("Red WINS by Conquest Victory")
		else:
			print("Blue WINS by Conquest Victory")
	if is_pilgrimage_victory():
		if blue:
			print("Red WINS by Pilgrimage Victory")
		else:
			print("Blue WINS by Pilgrimage Victory")
	if is_resignation_victory():
		if !blue:
			print("Red WINS by Resignation Victory")
		else:
			print("Blue WINS by Resignation Victory")
func is_conquest_victory():
	if board[6][0] == 6:
		return true
	if board[9][19] == -6:
		return true
	return false
func is_pilgrimage_victory():
	for j in BOARD_WIDTH:
		if board[2][j] == -6:
			return true
		if board[13][j] == 6:
			return true
	return false
func is_resignation_victory():
	return false
func movement(movement_pattern, building_capture : bool, piece_position, companion, movement_range, infiltrator : bool):
	var _moves = []
	if !battlefield(piece_position): return _moves
	var directions = []
	var knight = [Vector2(2, 1), Vector2(2, -1), Vector2(1, 2), Vector2(1, -2),	
				Vector2(-2, 1), Vector2(-2, -1), Vector2(-1, 2), Vector2(-1, -2)]
	var straight = [Vector2(0, 1), Vector2(0, -1), Vector2(1, 0), Vector2(-1, 0)]
	var diagonal = [Vector2(1, 1), Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1)]
	if movement_pattern.contains("knight"):
		for r in knight:
			directions.append(r)
	if movement_pattern.contains("straight"):
		for r in straight:
			directions.append(r)
	if movement_pattern.contains("diagonal"):
		for r in diagonal:
			directions.append(r)
	for i in directions:
		var pos = piece_position
		var stop_now = movement_range
		pos += i
		while battlefield(pos) && stop_now != 0:
			if companion != 0 && is_empty(piece_position+i+i) && is_board(piece_position+i,companion) && battlefield(piece_position+i+i):
				_moves.append(piece_position+i)
			if is_empty(pos): _moves.append(pos)
			elif ((is_enemy_incl(pos) && building_capture) || is_enemy(pos)) && enemy_ranks(piece_position):
				_moves.append(pos)
				break
			elif ((is_enemy_incl(pos) && building_capture) || is_enemy(pos)) && !infiltrator:
				_moves.append(pos)
				break
			elif !(get_board(pos) == companion * move_from_team) || companion == 0: 
				exception_handler(pos, _moves, piece_position)
				break
			pos += i
			stop_now += -1
	moves_cull(_moves)
	return _moves
func enemy_ranks(pos):
	if (pos.x <= 5 && !blue) || (pos.x >= 10 && blue):
		return true
	return false
func home_ranks(pos):
	if (pos.x <= 5 && blue) || (pos.x >= 10 && !blue):
		return true
	return false
func is_board(get_pos, piece_id):
	var output = board[get_pos.x][get_pos.y]
	if output * move_from_team == piece_id:
		return true
	return false


func _on_check_button_button_up() -> void:
	if administrator:
		administrator = false
		TURN_MARKER = preload("res://dunji_assets/timer.png")
	else:
		administrator = true
		TURN_MARKER = preload("res://dunji_assets/timer_admin.png")
	delete_dots()
	state = false
func _on_rotation_button_button_up() -> void:
	$"../Camera2D".rotation_degrees = round(abs($"../Camera2D".rotation_degrees-180))
	GlobalOrientation.blue_perspective = !GlobalOrientation.blue_perspective
	config.set_value("settings", "rotation", GlobalOrientation.blue_perspective)
	config.save("res://config.cfg")
func _on_quit_button_up() -> void:
	get_tree().quit()
