extends Node


var blue_perspective = true
